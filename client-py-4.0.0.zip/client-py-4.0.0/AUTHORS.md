Credits
=======

“fhirclient” is written and maintained by the SMART Platforms Team / Boston Children's Hospital.


Contributors
------------

The following wonderful people contributed directly or indirectly to this project:

- Erik Wiffin <https://github.com/erikwiffin>
- Josh Mandel <https://github.com/jmandel>
- Nikolai Schwertner <https://github.com/nschwertner>
- Pascal Pfiffner <https://github.com/p2>
- Raheel Sayeed <https://github.com/raheelsayeed> 
- Trinadh Baranika <https://github.com/bktrinadh>

Please add yourself here alphabetically when you submit your first pull request.
